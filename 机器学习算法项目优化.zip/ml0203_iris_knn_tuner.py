import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import ListedColormap
from sklearn.datasets import load_iris

# %matplotlib inline

iris = load_iris()  # 加载数据
X = iris.data[:, (1, 3)]  # 为方便画图，仅采用数据的其中两个特征
y = iris.target

cmap_light = ListedColormap(['#FFAAAA', '#AAFFAA', '#AAAAFF'])
cmap_bold = ListedColormap(['#FF0000', '#00FF00', '#0000FF'])

# 决策边界，用不同颜色表示
x_min, x_max = X[:, 0].min() - 0.1, X[:, 0].max() + 0.1
y_min, y_max = X[:, 1].min() - 0.1, X[:, 1].max() + 0.1
xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.02),
                     np.arange(y_min, y_max, 0.02))


def knn_code(loc, k=5, order=2):  # k order是超参
    diff_loc = X - loc
    dis_loc = np.linalg.norm(diff_loc, ord=order, axis=1)
    knn = y[dis_loc.argsort()[:k]]
    counts = np.bincount(knn)
    return np.argmax(counts)


line_loc = np.array(list(zip(xx.ravel(), yy.ravel())))

plt.figure(figsize=(15, 12))  # 图的尺寸

pos = 1  # 位置计数器

for k in [2, 6]:
    for order in [1, 2]:
        Z = np.array([knn_code(ii, k, order) for ii in line_loc]).reshape(xx.shape)  # 这个是不支持向量化运算的
        ax = plt.subplot(220 + pos)  # 几行，几列，第几个，先按行数
        ax.pcolormesh(xx, yy, Z, cmap=cmap_light)  # 绘制预测结果图
        ax.scatter(X[:, 0], X[:, 1], c=y, cmap=cmap_bold)  # 补充训练数据点
        ax.set_title(f'k: {k}, distance order: {order}')
        pos += 1

plt.suptitle('I am a tuner!')
