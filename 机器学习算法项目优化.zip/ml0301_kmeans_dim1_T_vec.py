# 输入 人的年龄 组数k 初始中心
# 输出 类的中心，类的元素
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# 输入部分
ages = np.array([1, 3, 5, 8, 9, 11, 12, 13, 37, 43, 45, 49, 51, 65])
k = 3

centers_new = [1, 20, 40]  # 迭代起点 实际实现时可以随机选择

# 探索部分
ages_series = pd.Series(ages)
plt.scatter(ages_series, np.zeros(len(ages_series)))  # 画图以后

# 重复部分 这个需要手动重复，请大家改成自动重复或确定收敛条件
centers = centers_new.copy()

# 向量化运算 距离表的数据结构 直接决定 口决，后对齐，相等一
dis_to_cent = np.abs(ages[:, np.newaxis] - centers)

clusters = dis_to_cent.argmin(axis=1)

for ii in range(k):
    cluster = ages[clusters == ii]
    centers_new[ii] = round(ages[clusters == ii].mean())

print(centers, centers_new)
print('centers_new==centers?', centers_new == centers)
print()
