# 输入 人的年龄 组数k 初始中心
# 输出 类的中心，类的元素
import numpy as np

# 输入部分
ages = np.array([1, 3, 5, 8, 9, 11, 12, 13, 37, 43, 45, 49, 51, 65])
k = 3
centers = None
# centers_new = [1, 20, 40]  # 迭代起点
# centers_new = [1, 3, 5]  # 迭代起点 不同的起点，相同的结果
# centers_new = [30, 31, 32]  # 迭代起点 不同的起点，不同的结果 这个有“分不着的情况”
centers_new = [49, 51, 65]  # 迭代起点 不同的起点，不同的结果

# 距离表的数据结构
dis_to_cent = np.zeros((len(ages), k))  # 一个二维数据，就是PPT的那个表

# 重复部分
while centers_new != centers:
    centers = centers_new.copy()  # 注意python的赋值过程，进行展开讲解，== is 和复制方式
    for ii in range(k):
        dis_to_cent[:, ii] = np.abs(ages - centers[ii])

    clusters = dis_to_cent.argmin(axis=1)

    for ii in range(k):
        cluster = ages[clusters == ii]
        if len(ages[clusters == ii]) > 0:  # 这部分用以解决个别类没有数据的情况
            centers_new[ii] = round(ages[clusters == ii].mean())
        else:
            centers_new[ii] = centers[ii]
    print(centers, centers_new)
    print('centers_new==centers?', centers_new == centers)
    print()
