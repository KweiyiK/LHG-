# 输入 人的年龄 组数k 初始中心
# 输出 类的中心，类的元素
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# 输入部分
ages = np.array([1, 3, 5, 8, 9, 11, 12, 13, 37, 43, 45, 49, 51, 65])
k = 3

centers_new = [1, 20, 40]  # 迭代起点 实际实现时可以随机选择

# 探索部分
ages_series = pd.Series(ages)
plt.scatter(ages_series, np.zeros(len(ages_series)))  # 画图以后

# 距离表的数据结构
dis_to_cent = np.zeros((len(ages), k))

# 重复部分 这个需要手动重复，请大家改成自动重复或确定收敛条件
centers = centers_new.copy()  # 注意python的赋值过程，进行展开讲解，== is 和复制方式
for ii in range(k):
    dis_to_cent[:, ii] = np.abs(ages - centers[ii])

clusters = dis_to_cent.argmin(axis=1)

for ii in range(k):
    cluster = ages[clusters == ii]
    centers_new[ii] = round(cluster.mean())

print(centers, centers_new)
print('centers_new==centers?', centers_new == centers)
print()
