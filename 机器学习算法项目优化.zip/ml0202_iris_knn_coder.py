import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import ListedColormap
from sklearn.datasets import load_iris

# %matplotlib inline

iris = load_iris()  # 加载数据
X = iris.data[:, (1, 3)]  # 为方便画图，仅采用数据的其中两个特征
y = iris.target

cmap_light = ListedColormap(['#FFAAAA', '#AAFFAA', '#AAAAFF'])
cmap_bold = ListedColormap(['#FF0000', '#00FF00', '#0000FF'])

# 决策边界，用不同颜色表示
x_min, x_max = X[:, 0].min() - 0.1, X[:, 0].max() + 0.1
y_min, y_max = X[:, 1].min() - 0.1, X[:, 1].max() + 0.1
xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.02),
                     np.arange(y_min, y_max, 0.02))


# # 核心的体会
# 几句“人话”，精准落地，不易
# 尽量找现成的方法：对于初学者不易，但最好正面解决
def knn_code(loc, k=5):  # 核心算法，看懂、背过、包括每一个方法（都很常用，要求能够自己写出来）
    # 算距离
    diff_loc = X - loc  # 坐标差
    dis_loc = np.linalg.norm(diff_loc, axis=1)  # 距离（手算也行，现成的方法为好，要习惯于使用现成的方法）
    # 取K
    knn = y[dis_loc.argsort()[:k]]  # argsort的技巧 排序的是距离，取数的是标签
    # 取类标
    counts = np.bincount(knn)  # 计数（整数） 这里面隐藏着索引
    return np.argmax(counts)  # 这个和计数是配套的


line_loc = np.array(list(zip(xx.ravel(), yy.ravel())))
Z = np.array([knn_code(ii) for ii in line_loc]).reshape(xx.shape)  # 这个是不支持向量化运算的

plt.figure()  # 张开一张画布
plt.pcolormesh(xx, yy, Z, cmap=cmap_light)  # 绘制预测结果图
plt.scatter(X[:, 0], X[:, 1], c=y, cmap=cmap_bold)  # 补充训练数据点

plt.title("I am a coder!")
plt.show()

"""
对向量化运算要求较高
"""
