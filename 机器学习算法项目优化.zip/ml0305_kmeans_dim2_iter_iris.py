# 输入 人的年龄 组数k 初始中心
# 输出 类的中心，类的元素

import numpy as np
import matplotlib.pyplot as plt


from sklearn.datasets import load_iris

import pylab as mpl  # import matplotlib as mpl

mpl.rcParams['font.sans-serif'] = ['FangSong']  # 指定默认字体
mpl.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题


iris = load_iris()  # 加载数据
y = iris.target  # 标签，有决定意义的标签，来自业务（老天爷）
feat_names = iris.feature_names  # 坐标轴的标记
ages = iris.data[:, (1, 3)]  # 为方便画图，仅采用数据的其中两个特征


# 输入部分
k = 3

np.random.seed(25)
centers = np.zeros([3, 2])
centers_random = np.random.choice(range(len(y)), 3)  # 迭代起点
centers_new = ages[centers_random]

dis_to_cent = np.zeros((k, len(ages)))  # 一个二维数据，就是PPT的那个表

# 重复部分 这个需要手动重复，请大家改成自动重复或确定收敛条件
while not (centers_new == centers).all():
    centers = centers_new.copy()  # 注意python的赋值过程，进行展开讲解，== is 和复制方式
    for ii in range(k):
        dis_to_cent[ii] = np.linalg.norm(ages - centers[ii], axis=1)

    clusters = dis_to_cent.argmin(axis=0)

    for ii in range(k):
        cluster = ages[clusters == ii]
        centers_new[ii] = ages[clusters == ii].mean(0)

    print(centers, centers_new)
    print(centers_new)
    print('centers_new==centers?', (centers_new == centers).all())
    print()

plt.figure(figsize=(8, 4))
ax = plt.subplot(121)  # 几行，几列，第几个，先按行数
ax.scatter(ages[:, 0], ages[:, 1], c=y)  # x, y, 颜色，系统有基本的选择机制，不用写得太细
ax.set_xlabel(feat_names[0])
ax.set_ylabel(feat_names[1])
ax.set_title('数据本身的标签')

ax = plt.subplot(122)  # 几行，几列，第几个，先按行数
ax.scatter(ages[:, 0], ages[:, 1], c=clusters)  # x, y, 颜色，系统有基本的选择机制，不用写得太细
ax.set_xlabel(feat_names[0])
ax.set_ylabel(feat_names[1])
ax.set_title('聚类的结果')
