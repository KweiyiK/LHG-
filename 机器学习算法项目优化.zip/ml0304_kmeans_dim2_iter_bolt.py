# 输入 人的年龄 组数k 初始中心
# 输出 类的中心，类的元素

import matplotlib.pyplot as plt
import numpy as np
import pylab as mpl  # import matplotlib as mpl
from sklearn.datasets import make_blobs

mpl.rcParams['font.sans-serif'] = ['FangSong']  # 指定默认字体
mpl.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题

n_samples = 1500  # 1500
random_state = 170  # 170
X, y = make_blobs(n_samples=n_samples, random_state=random_state)
ages = np.vstack((X[y == 0][:500], X[y == 1][:500], X[y == 2][:500]))
y = np.array(([0] * 500 + [1] * 500 + [2] * 500))

# 输入部分
k = 3

np.random.seed(26)
centers = np.zeros([3, 2])
centers_random = np.random.choice(range(len(y)), 3)  # 迭代起点
centers_new = ages[centers_random]

dis_to_cent = np.zeros((k, len(ages)))  # 一个二维数据，就是PPT的那个表

# 重复部分 这个需要手动重复，请大家改成自动重复或确定收敛条件
while not (centers_new == centers).all():
    centers = centers_new.copy()  # 注意python的赋值过程，进行展开讲解，== is 和复制方式
    for ii in range(k):
        dis_to_cent[ii] = np.linalg.norm(ages - centers[ii], axis=1)

    clusters = dis_to_cent.argmin(axis=0)

    for ii in range(k):
        cluster = ages[clusters == ii]
        centers_new[ii] = ages[clusters == ii].mean(0)

    print(centers, centers_new)
    print(centers_new)
    print('centers_new==centers?', (centers_new == centers).all())
    print()

plt.figure(figsize=(8, 4))
ax = plt.subplot(121)  # 几行，几列，第几个，先按行数
ax.scatter(ages[:, 0], ages[:, 1], c=y)  # x, y, 颜色，系统有基本的选择机制，不用写得太细

ax.set_title('数据本身的标签')

ax = plt.subplot(122)  # 几行，几列，第几个，先按行数
ax.scatter(ages[:, 0], ages[:, 1], c=clusters)  # x, y, 颜色，系统有基本的选择机制，不用写得太细

ax.set_title('聚类的结果')
