# 基于字典、列表、pandas实现。
# 仔细体会数据结构的力量
import pandas as pd

melon2 = pd.read_csv('lesson/melon_data/melon2.0.csv', index_col='编号')

m2_good = melon2[melon2['好瓜'] == '是']
m2_bad = melon2[melon2['好瓜'] == '否']

# # 好不好的先验
p_good_priori = (len(m2_good) + 1) / (len(melon2) + 2)
p_bad_priori = (len(m2_bad) + 1) / (len(melon2) + 2)

# # 各个特征的好、不好的拉普拉斯平滑：使用列表作为整体，每个特征实现一个字典
# 计数每个特征的值类别数
feature_num = melon2.shape[-1] - 1  # 全局性隐含特征序一致
features_name = []  # 特征的值的集合，这里一致，然后防止好瓜、坏瓜中没有相关的特征值
features_counts = []  # 特征的个数，可以拉普拉斯平滑的分母修正项
for ii in range(feature_num):
    features_name.append(set(melon2.iloc[:, ii]))
    features_counts.append(len(set(melon2.iloc[:, ii])))

# 好瓜部分
ps_feature_good = []
# 先对特征计数
for ii in range(feature_num):
    ps_feature_good.append(dict(m2_good.iloc[:, ii].value_counts()))  # Series本质上就是字典
# 然后用拉普拉斯计算条件概率
for ii in range(feature_num):
    for ff in features_name[ii]:  # 下一行的get防止出空
        ps_feature_good[ii][ff] = (ps_feature_good[ii].get(ff, 0) + 1) / (len(m2_good) + features_counts[ii])

# 坏瓜部分
ps_feature_bad = []
# 先对特征计数
for ii in range(feature_num):
    ps_feature_bad.append(dict(m2_bad.iloc[:, ii].value_counts()))
# 然后用拉普拉斯计算条件概率
for ii in range(feature_num):
    for ff in features_name[ii]:
        ps_feature_bad[ii][ff] = (ps_feature_bad[ii].get(ff, 0) + 1) / (len(m2_bad) + features_counts[ii])


# # 预测的函数 好坏分开，连乘比大小
def predict(features):
    p_good = p_good_priori
    for ii in range(feature_num):
        p_good *= ps_feature_good[ii][features[ii]]

    p_bad = p_bad_priori
    for ii in range(feature_num):
        p_bad *= ps_feature_bad[ii][features[ii]]

    return '是' if p_good > p_bad else '否'


# 验证结果
for idx in melon2.index:
    print(predict(melon2.loc[idx]), melon2.loc[idx][-1],
          predict(melon2.loc[idx]) == melon2.loc[idx][-1])

