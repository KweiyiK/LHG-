import pymysql

# 简单的查找  # 连接数据库
conn = pymysql.connect(host='127.0.0.1', user='spider',
                       password='spider01', database='bilibili')
cursor = conn.cursor(cursor=pymysql.cursors.DictCursor)

sql = 'select * from animate'

row = cursor.execute(sql)
result = cursor.fetchall()

# 最后打印获取到的数据
# print(result)
for ii in result:
    print(ii)
